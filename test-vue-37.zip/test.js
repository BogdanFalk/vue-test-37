export function printTest() {
    console.log("Harro!");
}